package finalproject;

public class WeatherInformerRunner {
	public static void main(String args[]) {
		UserInteractor i = new UserInteractor();
		String Zipcode = i.getZipcodeFromUser();
	}
}
